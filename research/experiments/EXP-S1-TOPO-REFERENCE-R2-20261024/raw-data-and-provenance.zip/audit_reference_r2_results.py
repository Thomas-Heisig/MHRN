"""Recompute R2 observations and sign tests from saved spike traces; no simulation."""
import json
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "r2-results-20261024"
data = json.loads((ROOT / "reference-data.json").read_text(encoding="utf-8"))
analysis = json.loads((ROOT / "analysis.json").read_text(encoding="utf-8"))
assert len(data["runs"]) == 120
lookup = {}
for row in data["runs"]:
    spikes = row["spike_times_by_label"]
    assert len(spikes) == 64
    assert all(0 <= tick < 128 for times in spikes.values() for tick in times)
    output_times = [tick for label in range(60, 64) for tick in spikes[str(label)]]
    latency = min(output_times, default=129)
    cumulative = [sum(bool(times) and min(times) <= tick for times in spikes.values())
                  for tick in range(128)]
    assert cumulative == row["cumulative_active_neurons_per_tick"]
    assert latency == row["first_output_latency_censored"]
    assert sum(cumulative[:32]) / 64 == row["activation_auc_0_32"]
    assert sum(map(len, spikes.values())) == row["total_spikes"]
    assert sum(row["delivered_events_per_tick"]) == row["delivered_events"]
    assert row["node_count"] == 64 and row["edge_count"] == 246
    key = (row["condition"], row["seed"])
    assert key not in lookup
    lookup[key] = row

checks = []
for item in analysis["primary_tests"]:
    left, right = item["contrast"]
    differences = [lookup[(right, seed)]["first_output_latency_censored"] -
                   lookup[(left, seed)]["first_output_latency_censored"]
                   for seed in data["seeds"]]
    assert differences == item["paired_differences"]
    assert statistics.median(differences) == item["median_difference"]
    n = sum(x != 0 for x in differences)
    positive = sum(x > 0 for x in differences)
    tail = min(positive, n - positive)
    p = min(1.0, 2 * sum(math.comb(n, i) for i in range(tail + 1)) / 2**n) if n else 1.0
    assert p == item["p_raw"]
    checks.append({"contrast": item["label"], "non_tied_pairs": n,
                   "positive_pairs": positive, "p_raw": p})
previous = 0.0
for rank, index in enumerate(sorted(range(5), key=lambda i: checks[i]["p_raw"])):
    corrected = max(previous, min(1.0, (5 - rank) * checks[index]["p_raw"]))
    assert corrected == analysis["primary_tests"][index]["p_holm"]
    previous = corrected
result = {"pass": True, "trace_runs_recomputed": 120, "primary_sign_tests": checks,
          "scope": "Internal separate arithmetic/trace audit, not independent scientific review"}
(ROOT / "trace-audit.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
