"""Execute the existing frozen R2 protocol; preserve receipts outside checkout."""
import hashlib
import json
import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "r2-run"
MAIN = ROOT / "MHRN"
OUT = ROOT / "r2-results-20261024"
FREEZE = MAIN / "research/preregistrations/PREREG-S1-TOPO-REFERENCE-R2.freeze.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(
        ["git", "-c", "safe.directory=*", *args], cwd=SOURCE, text=True
    ).strip()


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8", newline="\n")


def command(name, args, env):
    started = datetime.now(timezone.utc).isoformat()
    with (OUT / f"{name}.stdout.txt").open("wb") as stdout, (
        OUT / f"{name}.stderr.txt"
    ).open("wb") as stderr:
        result = subprocess.run(args, cwd=SOURCE, env=env, stdout=stdout,
                                stderr=stderr, timeout=3600, check=False)
    write(f"{name}.process.json", {"command": args, "cwd": str(SOURCE),
          "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
          "exit_code": result.returncode})
    if result.returncode:
        raise RuntimeError(f"{name} failed: {result.returncode}; artifacts retained")


def main():
    if OUT.exists():
        raise FileExistsError(OUT)
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    assert git("rev-parse", "HEAD") == freeze["freeze_commit"]
    assert not git("status", "--porcelain", "--untracked-files=all")
    checked = {}
    for value in freeze.values():
        if isinstance(value, dict) and "path" in value and "sha256" in value:
            name = value["path"].replace("\\", "/")
            assert sha(SOURCE / name) == value["sha256"], name
            checked[name] = value["sha256"]
    for name, digest in freeze["contract_tests"].items():
        name = name.replace("\\", "/")
        assert sha(SOURCE / name) == digest, name
        checked[name] = digest
    prereg = SOURCE / "research/preregistrations/PREREG-S1-TOPO-REFERENCE-R2.json"
    assert sha(prereg) == freeze["preregistration_sha256_before_status_update"]
    import brian2
    assert brian2.__version__ == "2.10.1"
    assert sys.version_info[:2] == (3, 13)
    OUT.mkdir()
    env = {**os.environ, "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1",
           "GIT_CONFIG_COUNT": "1", "GIT_CONFIG_KEY_0": "safe.directory",
           "GIT_CONFIG_VALUE_0": str(SOURCE)}
    command("contract-tests", [sys.executable, "-m", "pytest", "-p", "no:cacheprovider",
            "tests/test_stage1_reference_r2_contract.py",
            "tests/test_stage1_reference_r2_preflight.py", "-q",
            f"--basetemp={OUT / 'test-temp'}"], env)
    command("independence", [sys.executable, "scripts/check_stage1_reference_independence.py"], env)
    command("seed-freshness", [sys.executable, "scripts/check_stage1_reference_seed_freshness_r2.py"], env)
    (OUT / "pip-freeze.txt").write_bytes(subprocess.check_output([sys.executable, "-m", "pip", "freeze"]))
    write("execution-authorization.json", {
        "recorded_before_execution_utc": datetime.now(timezone.utc).isoformat(),
        "authority": "User instruction in current conversation",
        "instruction_verbatim": "beginne mit den experimenten und ihren auswertungen ,",
        "scope_selection": "Agent selected ready, previously frozen Stage-1 reference R2",
        "execution_authorized": True, "scientific_human_review_performed": False,
        "evidence_promotion_authorized": False, "freeze_sha256": sha(FREEZE),
        "source_commit": git("rev-parse", "HEAD"), "source_tree": git("rev-parse", "HEAD^{tree}"),
        "runner_sha256": freeze["reference_runner"]["sha256"],
        "checked_bound_files": checked, "preregistration_sha256": sha(prereg),
        "driver_sha256": sha(Path(__file__)), "python": sys.version,
        "platform": platform.platform(), "brian2": brian2.__version__,
        "no_outcome_inspection_before_authorization": True,
    })
    print("Preflight passed; starting frozen reference runner", flush=True)
    env["MHRN_STAGE1_REFERENCE_EXECUTION"] = "AUTHORIZED_REFERENCE_R2"
    command("reference-run", [sys.executable, "reference/stage1_topology_brian2/runner_r2.py",
            "--output", str(OUT / "reference-data.json")], env)
    print("Raw DATA persisted; starting separate frozen verifier", flush=True)
    command("analysis", [sys.executable, "scripts/verify_stage1_topology_reference_r2.py",
            "--data", str(OUT / "reference-data.json"), "--output", str(OUT / "analysis.json")], env)
    assert not git("status", "--porcelain", "--untracked-files=all")
    write("checksums.json", {p.name: sha(p) for p in OUT.iterdir() if p.is_file()})
    print((OUT / "analysis.stdout.txt").read_text(encoding="utf-8"), flush=True)


if __name__ == "__main__":
    main()
